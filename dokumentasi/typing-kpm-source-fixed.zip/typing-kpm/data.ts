import type { Lang } from "./types";

export const LANGS: { id: Lang; name: string; flag: string }[] = [
  { id: "id", name: "Indonesia", flag: "🇮🇩" },
  { id: "en", name: "Inggris", flag: "🇬🇧" },
];

export const DURATIONS = [15, 30, 60, 120];

const WORDS: Record<Lang, string[]> = {
  id: "yang dan di ke dari untuk dengan ini itu pada adalah dalam tidak akan juga atau saya kami kita mereka anda dia sudah belum bisa harus ingin mau lebih sangat banyak sedikit besar kecil baru lama baik cepat lambat rumah sekolah kantor kota desa jalan pasar kerja belajar bermain makan minum tidur bangun pagi siang sore malam hari minggu bulan tahun waktu uang buku meja kursi pintu jendela air api angin tanah langit laut gunung sungai hutan pohon bunga hujan matahari bintang teman keluarga ibu bapak anak guru murid dokter petani nelayan senyum tertawa berjalan berlari melihat mendengar berpikir menulis membaca bertanya menjawab mencoba berhasil kopi teh nasi ikan ayam".split(" "),
  en: "the be to of and a in that have it for not on with he as you do at this but his by from they we say her she or an will my one all would there their what so up out if about who get which go me when make can like time no just him know take people into year your good some could them see other than then now look only come its over think also back after use two how our work first well way even new want because any these give day most us".split(" "),
};

export function makeWords(lang: Lang, count: number) {
  const source = WORDS[lang];
  const result: string[] = [];

  for (let i = 0; i < count; i++) {
    let word = "";
    do {
      word = source[Math.floor(Math.random() * source.length)];
    } while (word === result[i - 1]);
    result.push(word);
  }

  return result;
}
