"use client";

import { useLayoutEffect, useRef } from "react";
import type { Lang, Rec } from "./types";

type Props = {
  lang: Lang;
  words: string[];
  wordIndex: number;
  current: string;
  records: Rec[];
  focused: boolean;
  status: "idle" | "running" | "done";
  elapsed: number;
  duration: number;
  onType: (value: string) => void;
  onReset: () => void;
  onFocusChange: (value: boolean) => void;
};

export default function TypingArea({
  lang,
  words,
  wordIndex,
  current,
  records,
  focused,
  status,
  elapsed,
  duration,
  onType,
  onReset,
  onFocusChange,
}: Props) {
  const boxRef = useRef<HTMLDivElement>(null);
  const activeWordRef = useRef<HTMLSpanElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Browser yang membungkus kata berdasarkan lebar aktual.
  // Saat kata aktif masuk baris ketiga, geser satu baris.
  useLayoutEffect(() => {
    const box = boxRef.current;
    const active = activeWordRef.current;
    if (!box || !active) return;

    const boxRect = box.getBoundingClientRect();
    const activeRect = active.getBoundingClientRect();
    const bottomLimit = boxRect.bottom - 12;

    if (activeRect.bottom > bottomLimit) {
      const lineHeight = 40;
      const overflow = activeRect.bottom - bottomLimit;
      const rowsToScroll = Math.max(1, Math.ceil(overflow / lineHeight));

      box.scrollTo({
        top: box.scrollTop + rowsToScroll * lineHeight,
        behavior: "auto",
      });
    }
  }, [wordIndex, words]);

  const renderWord = (word: string, index: number) => {
    if (index < wordIndex) {
      const record = records[index];
      return (
        <span
          key={index}
          className={
            record?.ok
              ? "text-slate-100"
              : "text-red-400 underline decoration-red-400/60"
          }
        >
          {word}
        </span>
      );
    }

    if (index === wordIndex) {
      return (
        <span
          key={index}
          ref={activeWordRef}
          className="rounded bg-slate-700/70"
        >
          {word.split("").map((character, charIndex) => {
            let className = "text-slate-400";

            if (charIndex < current.length) {
              className =
                current[charIndex] === character
                  ? "text-slate-100"
                  : "bg-red-500/30 text-red-400";
            }

            if (charIndex === current.length) {
              className += " border-b-2 border-amber-400";
            }

            return (
              <span key={charIndex} className={className}>
                {character}
              </span>
            );
          })}

          {current.length > word.length && (
            <span className="bg-red-500/30 text-red-400">
              {current.slice(word.length)}
            </span>
          )}
        </span>
      );
    }

    return (
      <span key={index} className="text-slate-500">
        {word}
      </span>
    );
  };

  const flag = lang === "id" ? "🇮🇩" : "🇬🇧";
  const progress = Math.min(100, (elapsed / duration) * 100);

  return (
    <section className="rounded-2xl bg-slate-800 p-4">
      <div className="mb-4 flex items-center justify-between gap-2">
        <div>
          <h2 className="text-lg font-bold">
            {flag} Ketik kata yang disorot
          </h2>
          <p className="text-xs text-slate-400">
            Tampilan otomatis memenuhi lebar area · 2 baris terlihat
          </p>
        </div>

        <button
          type="button"
          onClick={onReset}
          className="shrink-0 rounded-lg border border-slate-600 px-4 py-2 text-sm hover:bg-slate-700"
        >
          Acak ulang
        </button>
      </div>

      <div
        ref={boxRef}
        onClick={() => inputRef.current?.focus()}
        className="relative h-[104px] cursor-text overflow-hidden rounded-xl bg-slate-900 px-4 py-3"
      >
        <div
          className={`flex flex-wrap content-start gap-x-3 font-mono text-2xl leading-10 transition ${
            focused || status === "done" ? "" : "blur-sm"
          }`}
        >
          {words.map((word, index) => renderWord(word, index))}
        </div>

        {!focused && status !== "done" && (
          <div className="absolute inset-0 flex items-center justify-center bg-slate-900/40 px-3 text-center text-lg font-bold text-amber-300">
            Klik di sini lalu mulai mengetik
          </div>
        )}

        <input
          ref={inputRef}
          value={current}
          onChange={(event) => onType(event.target.value)}
          onFocus={() => onFocusChange(true)}
          onBlur={() => onFocusChange(false)}
          onPaste={(event) => event.preventDefault()}
          onKeyDown={(event) => {
            if (event.key === "Escape") {
              event.preventDefault();
              onReset();
              return;
            }

            // Tangani spasi secara langsung agar kata pasti berpindah,
            // meskipun browser tidak mengirim spasi melalui onChange.
            if (event.key === " ") {
              event.preventDefault();

              if (current.length > 0) {
                onType(`${current} `);
              }
            }
          }}
          disabled={status === "done"}
          autoComplete="off"
          autoCorrect="off"
          autoCapitalize="off"
          spellCheck={false}
          aria-label="Kolom mengetik"
          className="absolute left-0 top-0 h-px w-px opacity-0"
        />
      </div>

      <div className="mt-4 h-2 overflow-hidden rounded-full bg-slate-900">
        <div
          className="h-full bg-amber-400 transition-all"
          style={{ width: `${progress}%` }}
        />
      </div>

      <div className="mt-2 flex flex-wrap justify-between gap-2 text-sm text-slate-400">
        <span>
          {status === "done"
            ? "Waktu habis! Pilih riwayat atau lihat hasil tes."
            : "Tekan spasi untuk lanjut ke kata berikutnya."}
        </span>
        <span>ESC untuk mengulang</span>
      </div>
    </section>
  );
}
