"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import TypingArea from "./typing-kpm/TypingArea";
import ChartPanel from "./typing-kpm/ChartPanel";
import HistoryPanel from "./typing-kpm/HistoryPanel";
import { DURATIONS, LANGS, makeWords } from "./typing-kpm/data";
import { calcStats } from "./typing-kpm/utils";
import type { Lang, Mark, Rec, Result, Sample } from "./typing-kpm/types";

const STORAGE_KEY = "typing-app";

export default function Page() {
  const [lang, setLang] = useState<Lang>("id");
  const [duration, setDuration] = useState(30);
  const [words, setWords] = useState<string[]>([]);
  const [wordIndex, setWordIndex] = useState(0);
  const [current, setCurrent] = useState("");

  const [records, setRecords] = useState<Rec[]>([]);
  const [keys, setKeys] = useState(0);
  const [wrong, setWrong] = useState(0);
  const [samples, setSamples] = useState<Sample[]>([]);

  const [status, setStatus] = useState<"idle" | "running" | "done">("idle");
  const [elapsed, setElapsed] = useState(0);
  const [focused, setFocused] = useState(false);

  const [history, setHistory] = useState<Result[]>([]);
  const [best, setBest] = useState(0);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [loaded, setLoaded] = useState(false);

  const startedAt = useRef(0);
  const lastSecond = useRef(0);
  const currentWrong = useRef(0);
  const firstErrorAt = useRef<number | null>(null);

  const statsRef = useRef({ correct: 0, keys: 0, wrong: 0 });

  const correctChars = useMemo(() => {
    const completed = records.reduce(
      (sum, record) => sum + (record.ok ? record.word.length + 1 : 0),
      0
    );
    const currentCorrect = words[wordIndex]?.startsWith(current) ? current.length : 0;
    return completed + currentCorrect;
  }, [records, words, wordIndex, current]);

  statsRef.current = { correct: correctChars, keys, wrong };

  const liveStats = calcStats(correctChars, keys, wrong, Math.max(elapsed, 1));

  const currentMarks: Mark[] = useMemo(
    () =>
      records
        .filter((record) => record.wrong > 0)
        .map((record) => ({
          t: record.errAt ?? 0,
          word: record.word,
          typed: record.typed,
          ok: record.ok,
          wrong: record.wrong,
        })),
    [records]
  );

  const selectedResult =
    history.find((item) => item.id === selectedId) ?? null;

  const displaySamples =
    status === "running" || status === "idle"
      ? samples
      : selectedResult?.samples ?? samples;

  const displayMarks =
    status === "running" || status === "idle"
      ? currentMarks
      : selectedResult?.marks ?? currentMarks;

  const displayDuration =
    status === "running" || status === "idle"
      ? duration
      : selectedResult?.dur ?? duration;

  const displayResult =
    status === "done" ? selectedResult : null;

  const langLabel = LANGS.find((item) => item.id === lang)!;
  const remaining = Math.max(0, Math.ceil(duration - elapsed));

  const resetTest = (nextLang: Lang = lang, nextDuration = duration) => {
    setDuration(nextDuration);
    setWords(makeWords(nextLang, 180));
    setWordIndex(0);
    setCurrent("");
    setRecords([]);
    setKeys(0);
    setWrong(0);
    setSamples([]);
    setElapsed(0);
    setStatus("idle");
    setSelectedId(null);

    currentWrong.current = 0;
    firstErrorAt.current = null;
    lastSecond.current = 0;

    window.setTimeout(() => {
      const input = document.querySelector<HTMLInputElement>(
        'input[aria-label="Kolom mengetik"]'
      );
      input?.focus();
    }, 0);
  };

  useEffect(() => {
    let initialLang: Lang = "id";

    try {
      const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) ?? "{}");

      if (saved.lang === "id" || saved.lang === "en") {
        initialLang = saved.lang;
        setLang(saved.lang);
      }

      if (DURATIONS.includes(saved.duration)) {
        setDuration(saved.duration);
      }

      if (Array.isArray(saved.history)) {
        const normalized: Result[] = saved.history.map((item: Result) => ({
          ...item,
          id: item.id ?? `${Date.now()}-${Math.random()}`,
          marks: Array.isArray(item.marks) ? item.marks : [],
          samples: Array.isArray(item.samples) ? item.samples : [],
        }));
        setHistory(normalized);
      }

      if (typeof saved.best === "number") setBest(saved.best);
    } catch {
      // Abaikan data localStorage yang rusak.
    }

    setWords(makeWords(initialLang, 180));
    setLoaded(true);
  }, []);

  useEffect(() => {
    if (!loaded) return;

    try {
      localStorage.setItem(
        STORAGE_KEY,
        JSON.stringify({ lang, duration, history, best })
      );
    } catch {
      // localStorage penuh atau tidak tersedia.
    }
  }, [lang, duration, history, best, loaded]);

  useEffect(() => {
    if (status !== "running") return;

    const timer = window.setInterval(() => {
      const seconds = (Date.now() - startedAt.current) / 1000;

      if (seconds >= duration) {
        setElapsed(duration);
        setStatus("done");
        return;
      }

      setElapsed(seconds);

      const wholeSecond = Math.floor(seconds);
      if (wholeSecond > lastSecond.current) {
        lastSecond.current = wholeSecond;
        const stats = statsRef.current;
        const calculated = calcStats(
          stats.correct,
          stats.keys,
          stats.wrong,
          wholeSecond
        );

        setSamples((previous) => [
          ...previous,
          {
            t: wholeSecond,
            kpm: calculated.kpm,
            acc: calculated.acc,
          },
        ]);
      }
    }, 100);

    return () => window.clearInterval(timer);
  }, [status, duration]);

  useEffect(() => {
    if (status !== "done") return;

    const finalRecords = [...records];

    if (current && words[wordIndex] && currentWrong.current > 0) {
      finalRecords.push({
        word: words[wordIndex],
        typed: current,
        ok: false,
        wrong: currentWrong.current,
        errAt: firstErrorAt.current,
      });
    }

    const marks: Mark[] = finalRecords
      .filter((record) => record.wrong > 0)
      .map((record) => ({
        t: record.errAt ?? 0,
        word: record.word,
        typed: record.typed,
        ok: record.ok,
        wrong: record.wrong,
      }));

    const stats = calcStats(correctChars, keys, wrong, duration);
    const okWords = finalRecords.filter((record) => record.ok).length;
    const badWords = finalRecords.length - okWords;

    const finalSamples = [
      ...samples.filter((sample) => sample.t !== duration),
      { t: duration, kpm: stats.kpm, acc: stats.acc },
    ];

    const result: Result = {
      id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      ...stats,
      errors: wrong,
      okWords,
      badWords,
      lang,
      dur: duration,
      date: new Date().toLocaleString("id-ID", {
        day: "numeric",
        month: "short",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit",
      }),
      marks,
      samples: finalSamples,
    };

    setRecords(finalRecords);
    setSamples(finalSamples);
    setHistory((previous) => [result, ...previous].slice(0, 20));
    setSelectedId(result.id);
    setBest((previous) => Math.max(previous, result.kpm));
  }, [status]);

  const handleTyping = (rawValue: string) => {
    if (status === "done") return;

    const targetWord = words[wordIndex];
    if (!targetWord) return;

    const spaceIndex = rawValue.indexOf(" ");
    const value = spaceIndex >= 0 ? rawValue.slice(0, spaceIndex) : rawValue;

    if (value.length > targetWord.length + 8) return;

    if (status === "idle" && value.length > 0) {
      startedAt.current = Date.now();
      lastSecond.current = 0;
      setSamples([{ t: 0, kpm: 0, acc: 100 }]);
      setStatus("running");
    }

    const timeNow =
      status === "idle" ? 0 : (Date.now() - startedAt.current) / 1000;

    let addedKeys = 0;
    let addedWrong = 0;

    // Mencatat setiap karakter salah yang dimasukkan, meskipun kemudian dihapus.
    for (let index = current.length; index < value.length; index++) {
      addedKeys++;

      if (value[index] !== targetWord[index]) {
        addedWrong++;
        currentWrong.current++;

        if (firstErrorAt.current === null) {
          firstErrorAt.current = timeNow;
        }
      }
    }

    if (spaceIndex >= 0) {
      if (!value) return;

      const isCorrect = value === targetWord;

      if (!isCorrect && currentWrong.current === 0) {
        addedKeys++;
        addedWrong++;
        currentWrong.current = 1;
        firstErrorAt.current = timeNow;
      }

      const newRecord: Rec = {
        word: targetWord,
        typed: value,
        ok: isCorrect,
        wrong: currentWrong.current,
        errAt: firstErrorAt.current,
      };

      setRecords((previous) => [...previous, newRecord]);

      currentWrong.current = 0;
      firstErrorAt.current = null;

      setWordIndex((previous) => previous + 1);
      setCurrent("");

      if (words.length - (wordIndex + 1) < 70) {
        setWords((previous) => [...previous, ...makeWords(lang, 100)]);
      }
    } else {
      setCurrent(value);
    }

    if (addedKeys) setKeys((previous) => previous + addedKeys);
    if (addedWrong) setWrong((previous) => previous + addedWrong);
  };

  const changeLanguage = (nextLang: Lang) => {
    setLang(nextLang);
    resetTest(nextLang, duration);
  };

  const changeDuration = (nextDuration: number) => {
    setDuration(nextDuration);
    resetTest(lang, nextDuration);
  };

  const selectHistory = (result: Result) => {
    setSelectedId(result.id);
    setStatus("done");
    setElapsed(result.dur);
  };

  const clearHistory = () => {
    if (!window.confirm("Yakin ingin menghapus semua riwayat tes?")) return;
    setHistory([]);
    setBest(0);
    setSelectedId(null);
    setStatus("idle");
    setElapsed(0);
  };

  return (
    <main className="min-h-screen bg-slate-900 p-3 text-white sm:p-5">
      <div className="mx-auto max-w-7xl space-y-4">
        <section className="rounded-2xl bg-slate-800 p-4">
          <div className="grid gap-5 lg:grid-cols-3 lg:items-center">
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-2">
                {LANGS.map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => changeLanguage(item.id)}
                    className={`rounded-lg border px-3 py-2 font-bold transition ${
                      lang === item.id
                        ? "border-amber-400 bg-amber-400 text-slate-950"
                        : "border-slate-600 hover:bg-slate-700"
                    }`}
                  >
                    {item.flag} {item.name}
                  </button>
                ))}
              </div>

              <div className="grid grid-cols-4 gap-2">
                {DURATIONS.map((seconds) => (
                  <button
                    key={seconds}
                    type="button"
                    onClick={() => changeDuration(seconds)}
                    className={`rounded-lg border px-2 py-2 text-sm font-bold ${
                      duration === seconds
                        ? "border-amber-400 bg-amber-400 text-slate-950"
                        : "border-slate-600 hover:bg-slate-700"
                    }`}
                  >
                    {seconds >= 60 ? `${seconds / 60}m` : `${seconds}s`}
                  </button>
                ))}
              </div>
            </div>

            <div className="text-center">
              <div className="font-mono text-6xl font-bold text-amber-400 sm:text-7xl">
                {status === "done" && selectedResult
                  ? selectedResult.kpm
                  : liveStats.kpm}
              </div>
              <div className="text-sm text-slate-400">KPM (kata per menit)</div>
            </div>

            <div className="grid grid-cols-4 gap-2 text-center font-mono">
              {[
                [status === "done" && selectedResult ? selectedResult.cpm : liveStats.cpm, "CPM"],
                [`${status === "done" && selectedResult ? selectedResult.acc : liveStats.acc}%`, "Akurasi"],
                [status === "done" && selectedResult ? selectedResult.errors : wrong, "Kesalahan"],
                [`${status === "running" ? remaining : duration}s`, "Waktu"],
              ].map(([value, label]) => (
                <div key={String(label)}>
                  <div className="text-xl font-bold sm:text-2xl">{value}</div>
                  <div className="text-xs text-slate-400">{label}</div>
                </div>
              ))}
            </div>
          </div>
        </section>

        <TypingArea
          lang={lang}
          words={words}
          wordIndex={wordIndex}
          current={current}
          records={records}
          focused={focused}
          status={status}
          elapsed={elapsed}
          duration={duration}
          onType={handleTyping}
          onReset={() => resetTest()}
          onFocusChange={setFocused}
        />

        <div className="grid gap-4 lg:grid-cols-12 lg:items-start">
          <div className="lg:col-span-8">
            <ChartPanel
              title={
                status === "running"
                  ? "Grafik tes berjalan"
                  : displayResult
                    ? `Grafik riwayat · ${displayResult.date}`
                    : "Grafik tes"
              }
              samples={displaySamples}
              marks={displayMarks}
              duration={displayDuration}
              result={displayResult}
            />
          </div>

          <div className="lg:col-span-4">
            <HistoryPanel
              history={history}
              selectedId={selectedId}
              best={best}
              onSelect={selectHistory}
              onClear={clearHistory}
            />
          </div>
        </div>

        <p className="px-1 text-center text-xs text-slate-500">
          {langLabel.flag} {langLabel.name} · Riwayat dan grafik tersimpan otomatis di browser ini.
        </p>
      </div>
    </main>
  );
}
